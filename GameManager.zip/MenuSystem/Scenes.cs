public static class Scenes
{
    public const string MainMenu = "MainMenu";
    public const string Loading  = "Loading";
    public const string Game     = "GameScene"; // <-- make sure this matches your actual gameplay scene name
}
