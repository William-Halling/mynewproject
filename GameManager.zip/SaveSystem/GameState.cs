

public enum GameState
{
    MainMenu,
    Play,
    Paused, 
    Quit,
    Loading
}